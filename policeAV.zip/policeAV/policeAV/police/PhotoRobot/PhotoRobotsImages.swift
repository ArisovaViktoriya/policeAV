//
//  PhotoRobots.swift
//  police
//
//  Created by user on 21.09.2022.
//

import UIKit
import Alamofire
import SwiftyJSON

class PhotoRobotsImages: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    var arraysPhoto: [String] = []
    

    @IBOutlet weak var collection: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        request()
    }
    
    func request() {
        let uri = "https://jsonplaceholder.typicode.com/photos"
        AF.request(uri, method: .get).response { response in
            switch response.result {
            case .success(let value):
                let json = JSON(value!)
                for row in 0..<10 {
                    self.arraysPhoto.append(json[row]["url"].stringValue)
                }
                self.collection.reloadData()
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arraysPhoto.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! PhotoRobotsCell
        
        if indexPath.row % 2 == 0 {
            cell.layer.cornerRadius = 34
        } else {
            cell.layer.cornerRadius = 87
        }
        
        let imageUrlString = arraysPhoto[indexPath.row]
        let convertToUri = URL(string: imageUrlString)
        let imageData = try? Data(contentsOf: convertToUri!)
        
        cell.image.image = UIImage(data: imageData!)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(indexPath.row)
    }
}
